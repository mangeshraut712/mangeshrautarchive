export const ExternalApiKeys = Object.freeze({
    news: '7c0f446a765249edab2c14df05956792',
    nasa: 'AADXc64v1KehekFRHPZeqvR0mdD1DPwpSLUEsXhn'
});

export default ExternalApiKeys;
